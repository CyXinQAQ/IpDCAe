This is the code for paper "Yang Chen, Ziyan Luo. Group SLOPE penalized low-rank tensor regression, Journal of Machine Learning Research, 2023, 24:1-30" (https://jmlr.org/papers/v24/22-1327.html).
