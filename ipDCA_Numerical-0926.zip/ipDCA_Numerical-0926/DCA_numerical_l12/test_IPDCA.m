rng(20220129);
ntest = 30;
seedList = uint32(rand(ntest,1)*2^32);

% this is a first version, which aims to select appropriate parameters
% 2022.1.29v1
T0 = tic;
T_eig = 0;
fid = fopen('history.txt','w+');
fid = 1;
datatype = 'randn';
datatype = 'dct';

datatypelist = {'randn', 'dct'};

 datatypelist = {'dct'};

for i_datatype = 1:length(datatypelist)

    datatype =  datatypelist{i_datatype};
    switch datatype
        case 'randn'
%            lambda_list = [1e-3 5e-4];
          lambda_list = [5e-4];
            mns_list = [720 2560 80].*[1 2 3 4 5]';
        case 'dct'
            lambda_list = 1e-4;
            mns_list = [100 1500 20;
                100 1500 30;
                100 1500 40;
                120 1800 24;
                120 1800 36;
                120 1800 48];
  
    end
    for lambda = lambda_list
        for index = 1:size(mns_list,1)
            if lambda == 0.01
                tau_const_list = [0.75 0.8 0.85 0.90 0.95 0.99];
            else
                tau_const_list = [0.90 0.95 0.99];
                tau_const_list = [0.99];
            end
            n_solver = 4 + 4*length(tau_const_list); % + 1;
            Perf_ntest = zeros(n_solver,6);
            Perf = zeros(n_solver,6);
            
            % Lines 1:3, nesterov, old, new, bb
            % the remaing lines: tau_const, old, new, bb
            % first column: extrap, 0 denotes nestrov,
            % second column: tau_method, 0:old, 1:new, 2: new2, 3: lbb, 4: sbb, 5: abb
            %% generate the data
            m =  mns_list(index,1);
            n =  mns_list(index,2);
            s =  mns_list(index,3);
            
            matfile = sprintf('./results/m%dn%ds%d_ntest%d_lam_%2.1e_%s.mat',m,n,s,ntest,lambda,datatype);
            %         s = 160*index;
            %         m = 100; n = 15*m; s = 0.2*m;
            % m = 100;
            % n = 10*m;
            % s = 0.2*m;
            % m = 100*index;
            % n = 5*m;
            % A = normrnd(0,1,m,n);
            fprintf(fid,'m: %4d, n: %4d, s: %4d,lambda: %4.2e\n',m,n,s,lambda);
            for itest = 1:ntest
                rng(seedList(itest,1));
                fprintf(fid,'-----------------------     itest: %2d/%2d       -----------------------\n',...
                    itest,ntest);
                switch datatype
                    case 'randn'
                        A = randn(m,n);
                        for i=1:n
                            A(:,i)=A(:,i)/norm(A(:,i));
                        end
                    case 'dct'
                        F = 10;
                        A = zeros(m,n);
                        w = rand(m,1);
                        for j = 1:n
                            A(:,j) = cos((2*pi*j*w)/F)/sqrt(m);
                        end
                end
%                 tic
%                 condA = cond(A'*A);
%                 toc
                
                % 生成一个稀疏度为s的稀疏高斯分布的向量
                x_star=zeros(n,1);
                x_star(randperm(n,s))=randn(s,1);%n中s个位置生成高斯分布的向量
                %%
                % x_star=abs(x_star);
                eps=randn(m,1);
                b=A*x_star+0.01*eps;
                lambda_bound = 0.5*norm(A'*b,'inf');
                %L=max(eig(A'*A));
                t0_eig = tic;
                L = norm(A*A');
                t_eig = toc(t0_eig);
                T_eig = T_eig + t_eig;
                
                MaxIter = 2e6;
                %% do comparsion
                
                gtol = 1e-5;
                opts0.L = L;
                opts0.gtol = gtol;
                
                opts0.MaxIter = MaxIter;
              
                %         %%
%                 opts_PGelsBB.tol = gtol;
%                 opts_PGelsBB.L = L;
%                 opts_PGelsBB.delta = 0.1; opts_PGelsBB.restart = 0; opts_PGelsBB.re_freq = 200;
%                 opts_PGelsBB.display = 0;
%                 opts_PGelsBB.maxit = MaxIter;
%                 t0 = tic;
%                 out_PGelsBB = PGels_l1l2( A, b, lambda, lambda, opts_PGelsBB);
%                 t_PGelsBB = toc(t0);
%                 nls_PGelsBB = out_PGelsBB.NLS;
%                 f_PGelsBB = out_PGelsBB.hist_fval(end);
%                 iter_PGelsBB = out_PGelsBB.itnum;
%                 fprintf(fid,'%10s: %6.4e, %4d, %4d, %4.3f\n',...
%                     'PGelsBB',f_PGelsBB, iter_PGelsBB,nls_PGelsBB,t_PGelsBB);
                
                 %%  Nesterov + old stepsize
                opts = opts0;
                opts.extrap = 'nesterov';
                opts.rt = 200;
                opts.tau_method = 'old';
                t0 = tic;
               
                
                out_old= IPDCAe_new(A,b,lambda,n,opts);
                x_nesterov_old=out_old.x;
                f_nesterov_old=out_old.f_value;
                iter_nesterov_old=out_old.iter;
                nls_nesterov_old=out_old.nls;
                t_nestrov_old = toc(t0);
                fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    opts.extrap,opts.tau_method,f_nesterov_old, iter_nesterov_old,nls_nesterov_old,t_nestrov_old);
                
                %%  Nesterov + new stepsize
                opts = opts0;
                opts.extrap = 'nesterov';
                opts.rt = 200;
                opts.tau_method = 'new';
                t0 = tic;
                out_new = IPDCAe_new(A,b,lambda,n,opts);
                x_nesterov_new=out_new.x;
                f_nesterov_new=out_new.f_value;
                iter_nesterov_new=out_new.iter;
                nls_nesterov_new=out_new.nls;
                t_nestrov_old = toc(t0);
                t_nestrov_new = toc(t0);
                fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    opts.extrap,opts.tau_method,f_nesterov_new, iter_nesterov_new,nls_nesterov_new,t_nestrov_new);
                
                %%  Nesterov + new stepsize - 2
                opts = opts0;
                opts.extrap = 'nesterov';
                opts.rt = 200;
                opts.tau_method = 'new2';
                t0 = tic;
                out_new2 = IPDCAe_new(A,b,lambda,n,opts);
                x_nesterov_new2=out_new2.x;
                f_nesterov_new2=out_new2.f_value;
                iter_nesterov_new2=out_new2.iter;
                nls_nesterov_new2=out_new2.nls;
                t_nestrov_new2 = toc(t0);
                
                
                
                fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    opts.extrap,opts.tau_method,f_nesterov_new2, iter_nesterov_new2,nls_nesterov_new2,t_nestrov_new2);
                
                %             %%  Nesterov + lbb stepsize
                %             opts = opts0;
                %             opts.extrap = 'nesterov';
                %             opts.rt = 200;
                %             opts.tau_method = 'lbb';
                %
                %             t0 = tic;
                %             [x_nesterov_lbb,f_nesterov_lbb,iter_nesterov_lbb,nls_nesterov_lbb] = IPDCAe_new(A,b,lambda,n,opts);
                %             t_nestrov_lbb = toc(t0);
                %             fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                %                 opts.extrap,opts.tau_method,f_nesterov_lbb, iter_nesterov_lbb,nls_nesterov_lbb,t_nestrov_lbb);
                
                %%  Nesterov + sbb stepsize
                opts = opts0;
                opts.extrap = 'nesterov';
                opts.rt = 200;
                opts.tau_method = 'sbb';
                
                t0 = tic;
                out_sbb= IPDCAe_new(A,b,lambda,n,opts);
                x_nesterov_sbb=out_sbb.x;
                f_nesterov_sbb=out_sbb.f_value;
                iter_nesterov_sbb=out_sbb.iter;
                nls_nesterov_sbb=out_sbb.nls;
                t_nestrov_sbb = toc(t0);
                fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    opts.extrap,opts.tau_method,f_nesterov_sbb, iter_nesterov_sbb,nls_nesterov_sbb,t_nestrov_sbb);
                
                %             %%  Nesterov + abb stepsize
                %             opts = opts0;
                %             opts.extrap = 'nesterov';
                %             opts.rt = 200;
                %             opts.tau_method = 'abb';
                %
                %             t0 = tic;
                %             [x_nesterov_abb,f_nesterov_abb,iter_nesterov_abb,nls_nesterov_abb] = IPDCAe_new(A,b,lambda,n,opts);
                %             t_nestrov_abb = toc(t0);
                %             fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                %                 opts.extrap,opts.tau_method,f_nesterov_abb, iter_nesterov_abb,nls_nesterov_abb,t_nestrov_abb);
                
                
                
                Perf(1:4,:) = [-1, 0, f_nesterov_old, iter_nesterov_old,nls_nesterov_old,t_nestrov_old;
                                    -1, 1, f_nesterov_new, iter_nesterov_new,nls_nesterov_new,t_nestrov_new;
                    -1, 2, f_nesterov_new2, iter_nesterov_new2,nls_nesterov_new2,t_nestrov_new2;
                    %                 -1,3,f_nesterov_lbb, iter_nesterov_lbb,nls_nesterov_lbb,t_nestrov_lbb;
                    -1,4,f_nesterov_sbb, iter_nesterov_sbb,nls_nesterov_sbb,t_nestrov_sbb;
                    ];
                
                %% constant
                len_tau_const_list = length(tau_const_list);
                
                for i_tau_const = 1:len_tau_const_list
                    tau_const = tau_const_list(i_tau_const);
                    opts = opts0;
                    opts.extrap = 'constant';
                    opts.tau_const = tau_const;
                    % old
                    opts.tau_method = 'old';
                    t0 = tic;
                    out_cold= IPDCAe_new(A,b,lambda,n,opts);
                    x_constant_old=out_cold.x;
                    f_constant_old=out_cold.f_value;
                    iter_constant_old=out_cold.iter;
                    nls_constant_old=out_cold.nls;
                    t_constant_old = toc(t0);
                    
                    fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                        num2str(tau_const),opts.tau_method,f_constant_old, iter_constant_old,nls_constant_old,t_constant_old);
                    
                    % new
                    opts.tau_method = 'new';
                    t0 = tic;
                    out_cnew = IPDCAe_new(A,b,lambda,n,opts);
                    x_constant_new=out_cnew.x;
                    f_constant_new=out_cnew.f_value;
                    iter_constant_new=out_cnew.iter;
                    nls_constant_new=out_cnew.nls;
                    t_constant_new = toc(t0);
                    
                    fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                        num2str(tau_const),opts.tau_method,f_constant_new, iter_constant_new,nls_constant_new,t_constant_new);
                    
                    % new
                    opts.tau_method = 'new2';
                    t0 = tic;
                    out_cnew2 = IPDCAe_new(A,b,lambda,n,opts);
                    x_constant_new2=out_cnew2.x;
                    f_constant_new2=out_cnew2.f_value;
                    iter_constant_new2=out_cnew2.iter;
                    nls_constant_new2=out_cnew2.nls;
                
                    t_constant_new2 = toc(t0);
                    
                    fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                        num2str(tau_const),opts.tau_method,f_constant_new2, iter_constant_new2,nls_constant_new2,t_constant_new2);
                    
                    
                    %                 % lbb
                    %                 opts.tau_method = 'lbb';
                    %                 t0 = tic;
                    %                 [x_constant_lbb,f_constant_lbb,iter_constant_lbb,nls_constant_lbb] = IPDCAe_new(A,b,lambda,n,opts);
                    %                 t_constant_lbb = toc(t0);
                    %
                    %                 fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    %                     num2str(tau_const),opts.tau_method,f_constant_lbb, iter_constant_lbb,nls_constant_lbb,t_constant_lbb);
                    
                    % lbb
                    opts.tau_method = 'sbb';
                    t0 = tic;
                    out_csbb = IPDCAe_new(A,b,lambda,n,opts);
                    x_constant_sbb=out_csbb.x;
                    f_constant_sbb=out_csbb.f_value;
                    iter_constant_sbb=out_csbb.iter;
                    nls_constant_sbb=out_csbb.nls;
                    t_constant_sbb = toc(t0);
                    
                    fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                        num2str(tau_const),opts.tau_method,f_constant_sbb, iter_constant_sbb,nls_constant_sbb,t_constant_sbb);
                    
                    %                 % lbb
                    %                 opts.tau_method = 'abb';
                    %                 t0 = tic;
                    %                 [x_constant_abb,f_constant_abb,iter_constant_abb,nls_constant_abb] = IPDCAe_new(A,b,lambda,n,opts);
                    %                 t_constant_abb = toc(t0);
                    %
                    %                 fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    %                     num2str(tau_const),opts.tau_method,f_constant_abb, iter_constant_abb,nls_constant_abb,t_constant_abb);
                    
                    row_range = 1 + 4*i_tau_const: 4 + 4*i_tau_const;
                    Perf(row_range,:) = [tau_const, 0,f_constant_old, iter_constant_old,nls_constant_old,t_constant_old;
                                            tau_const, 1,f_constant_new, iter_constant_new,nls_constant_new,t_constant_new;
                        tau_const, 2,f_constant_new2, iter_constant_new2,nls_constant_new2,t_constant_new2;
                        %                     tau_const,3, f_constant_lbb, iter_constant_lbb,nls_constant_lbb,t_constant_lbb;
                        tau_const,4, f_constant_sbb, iter_constant_sbb,nls_constant_sbb,t_constant_sbb;
                        ];
                    
                end
                %             Perf(n_solver,:) = [-2, -2, f_PGelsBB, iter_PGelsBB,nls_PGelsBB,t_PGelsBB];
                
                Perf_ntest = Perf_ntest + Perf;
            end
            
            %         fprintf(1,'m: %4d, n: %4d, s: %4d,lambda: %4.2e\n',m,n,s,lambda);
            
            Perf_ntest = Perf_ntest/ntest;
            save(matfile,'m','n','s','lambda','ntest','Perf_ntest');
            
        end
    end
end
Tsolve = toc(T0);
T_eig;
