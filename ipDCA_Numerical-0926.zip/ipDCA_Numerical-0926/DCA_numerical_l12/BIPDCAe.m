function out= BIPDCAe(A,b,lambda,n,opts)
%E=@(x_new,x_old,t,tau,lambda,A,b,L) lambda*norm(x_new,1)-lambda*norm(x_new,2)+1/2*norm(A*x_new-b)^2+(t^2-t*(tau-1))/2*L*norm(x_new-x_old)^2;
% set matrix handles
Ahandle = @(x) A*x;
AThandle = @(x) A'*x;
x_new = zeros(n,1);
dx = zeros(n,1);
nrm_x_new = norm(x_new);
ATb = AThandle(b);
Ax_new = Ahandle(x_new);
ATAx_new = AThandle(Ax_new);
ATAx_old = ATAx_new;

if nrm_x_new <= 1e-8
    xi = zeros(n,1);
else
    xi = (lambda/nrm_x_new)*x_new;
end

grad_new = ATAx_new - ATb - xi;
%nrmd2 = 0;
nls = 0;

%% copy parameters
extrap = opts.extrap;
MaxIter = opts.MaxIter;
rt=opts.rt;
L = opts.L;


gtol = opts.gtol;
theta0 = 1; theta = 1;
eta=1.1;
for iter=1:MaxIter
    
    %% select the extrapolation parameter    switch extrap
    switch extrap
        case 'nesterov'
            % 重启Nesterov 加速
            t_old = (theta0 - 1)/theta;
            theta0 = theta;
            theta = (1 + sqrt(1+4*theta^2))/2;
        case 'constant'
            t_old = tau_const;
    end
    y = x_new+t_old*dx;
    
    
    dATAx = ATAx_new - ATAx_old;
    if iter>1
        L=norm(dATAx)^2/(dx'*dATAx);
    end
       
    grad_y = grad_new + t_old*dATAx;
    ATAx_old = ATAx_new;
    x_old = x_new;
    %E_old = E_new;
    Ay=Ahandle(y);
    g2y=0.5*norm(Ay-b)^2;
    gradient_g2y=grad_y+xi;
    nls_iter = 0;
    while 1
        
        x_new = shrinkage(y-1/(L)*grad_y,lambda/(L));
        Ax_new = Ahandle(x_new);
        
        ATAx_new = AThandle(Ax_new);
        dx = x_new - x_old;
        %nrmd2 = norm(dx)^2;
        nrm_x_new = norm(x_new);
        dxy=x_new-y;      
        
        E_left=0.5*norm(Ax_new-b)^2;
        E_right=g2y+gradient_g2y'*dxy+L/2*norm(dxy)^2;
        
        if E_left <= E_right+1e8
            out.step(iter)=1/L;
            break;
        end
        L=eta*L; %Line-search for local Lip
        nls_iter = nls_iter + 1;
    end
    nls = nls + nls_iter;
    % 停机准则 grad_new = AThandle(Ahandle(x_new)-b) - lambda*x_new/norm(x_new)
    
    % compute the subgradient
    if nrm_x_new <= 1e-8
        xi = zeros(n,1);
    else
        xi = (lambda/nrm_x_new)*x_new;
    end
    
    grad_new = ATAx_new - ATb - xi;
    proj_grad = grad_new;
    proj_grad(grad_new > lambda) = lambda;
    proj_grad(grad_new < -lambda) = -lambda;
    proj_grad = proj_grad - grad_new;
    
    if norm(proj_grad) < gtol %&& norm(x_new - x_old)/max(1,norm(x_new)) < gtol
        %         if norm(proj_grad) == 0
        %             pause;
        %         end
        %     if norm(x_old-x_new)/max(norm(x_new),1)<1e-5
        out.x=x_new;
        out.iter=iter;
        out.nls=nls;
        break;
    end
    
    if strcmp(extrap,'nesterov')
        if mod(iter,rt) == 0 || (y-x_new)'*(x_new-x_old) > 0
            theta0 = 1; theta = 1;
        end
    end
    
end
%输出数据
out.f_value=lambda*norm(x_new,1)-lambda*norm(x_new,2)+1/2*norm(A*x_new-b)^2;

