function out = IPDCAe_new(A,b,lambda,n,opts)
%E=@(x_new,x_old,t,tau,lambda,A,b,L) lambda*norm(x_new,1)-lambda*norm(x_new,2)+1/2*norm(A*x_new-b)^2+(t^2-t*(tau-1))/2*L*norm(x_new-x_old)^2;
% set matrix handles
Ahandle = @(x) A*x;
AThandle = @(x) A'*x;
% x_old = zeros(n,1);
x_new = zeros(n,1);
% x_old = x0;
% x_new = x_old;
dx = zeros(n,1);
nrm_x_new = norm(x_new);
ATb = AThandle(b);
Ax_new = Ahandle(x_new);
ATAx_new = AThandle(Ax_new);
ATAx_old = ATAx_new;
E_new = 0.5*norm(Ax_new - b)^2 + lambda*(norm(x_new,1));
if nrm_x_new <= 1e-8
    xi = zeros(n,1);
else
    xi = (lambda/nrm_x_new)*x_new;
end

grad_new = ATAx_new - ATb - xi;
nrmd2 = 0;
nls = 0;

%% copy parameters
extrap = opts.extrap;
L = opts.L;
MaxIter = opts.MaxIter;
if strcmp(extrap,'nesterov')
    rt = opts.rt;
elseif strcmp(extrap,'constant')
    tau_const = opts.tau_const;
end
tau_method = opts.tau_method;
gtol = opts.gtol;
theta0 = 1; theta = 1;
tau_new = 1/2;
for iter=1:MaxIter
    tau_old = tau_new;
    %% select the extrapolation parameter
    switch extrap
        case 'nesterov' 
            % 重启Nesterov 加速
            t_old = (theta0 - 1)/theta;
            theta0 = theta;
            theta = (1 + sqrt(1+4*theta^2))/2;
            theta_2 = (1 + sqrt(1+4*theta^2))/2;     
            t_new = (theta - 1)/theta_2;
            
            
        case 'constant'
            t_old = tau_const;
            t_new = tau_const;
     
    end
    
    y = x_new+t_old*dx;
    
    
    dATAx = ATAx_new - ATAx_old;
    %% select the stepsize
    if strcmp(tau_method,'new')
        tau_new =  max(tau_old,(t_new^2+t_new+t_old+1)/(t_new+t_old+2)+1e-5);
    elseif strcmp(tau_method,'new2')
        tau_new =  0.8*max(tau_old,(t_new^2+t_new+t_old+1)/(t_new+t_old+2)+1e-5);

    elseif strcmp(tau_method,'old')
        tau_new = 1;
    else
        if iter>=2
            switch tau_method
                case 'lbb'
                    tau_new = (dx'*dATAx)/nrmd2/L;
                case 'sbb'
                    tau_new = norm(dATAx)^2/(dx'*dATAx)/L;
                case 'abb'
                    if mod(iter,2) == 0
                        tau_new = (dx'*dATAx)/nrmd2/L;
                    else
                        tau_new = norm(dATAx)^2/(dx'*dATAx)/L;
                    end
            end
        else
            tau_new = min(max(t_old,(t_new^2+t_new+t_old+1)/(t_new+t_old+2)),1);
        end
    end

    
    grad_y = grad_new + t_old*dATAx;
    ATAx_old = ATAx_new;
    x_old = x_new;
    E_old = E_new;
    descent = 1e-4*nrmd2;
    nls_iter = 0;
    out.step(iter)=1/(tau_new*L);
    while 1
        
        x_new = shrinkage(y-1/(tau_new*L)*grad_y,lambda/(tau_new*L));
        Ax_new = Ahandle(x_new);
        ATAx_new = AThandle(Ax_new);
        temp_c = L*(t_new^2 + (1 - tau_new)*t_new)/2;
        dx = x_new - x_old;
        nrmd2 = norm(dx)^2;
        nrm_x_new = norm(x_new);
        E_new = 0.5*norm(Ax_new - b)^2 + lambda*norm(x_new,1)-x_new'*xi + temp_c*nrmd2;
        
        % compute E_new, A*x_new
        % fprintf(1,'E_new: %6.4e, E_old: %6.4e\n',E_new,E_old);
        
        if E_new <= E_old - descent + 100/iter^1.2
        %if E_new <= E_old - descent
            break;
        end
         
        nls_iter = nls_iter + 1;
    end
    nls = nls + nls_iter;
    % 停机准则 grad_new = AThandle(Ahandle(x_new)-b) - lambda*x_new/norm(x_new)
    
    % compute the subgradient
    if nrm_x_new <= 1e-8
        xi = zeros(n,1);
    else
        xi = (lambda/nrm_x_new)*x_new;
    end
    
    grad_new = ATAx_new - ATb - xi;
    proj_grad = grad_new;
    proj_grad(grad_new > lambda) = lambda;
    proj_grad(grad_new < -lambda) = -lambda;
    proj_grad = proj_grad - grad_new;
    
    if norm(proj_grad) < gtol %&& norm(x_new - x_old)/max(1,norm(x_new)) < gtol
        %         if norm(proj_grad) == 0
        %             pause;
        %         end
        %     if norm(x_old-x_new)/max(norm(x_new),1)<1e-5
        out.x=x_new;
        out.iter=iter;
        out.nls=nls;
        break;
    end
    
    if strcmp(extrap,'nesterov')
        if mod(iter,rt) == 0 || (y-x_new)'*(x_new-x_old) > 0
            theta0 = 1; theta = 1;
        end
    end
    
end
%输出数据
out.f_value=lambda*norm(x_new,1)-lambda*norm(x_new,2)+1/2*norm(A*x_new-b)^2;

