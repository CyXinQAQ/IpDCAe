fid = fopen('latex_IPDCAe.txt','w+');
fid = 1;
s_ratio = 1;
datatype = 'randn';
% datatype = 'dct';
switch datatype
    case 'randn'
        lambda_list = [1e-3 5e-4];
        mns_list = [720 2560 80].*[1 2 3 4 5]'; 
    case 'dct'
        lambda_list = 1e-4;
        mns_list = [100 1500 20; 
                    100 1500 30;
                    100 1500 40;
                    120 1800 24;
                    120 1800 36;
                    120 1800 48];
end
ntest = 1;
for lambda = lambda_list
    for index = 1:size(mns_list,1)
%         if lambda == 0.01
%             tau_const_list = [0.75 0.8 0.85 0.90 0.95 0.99];
%         else
%             tau_const_list = [0.90 0.95 0.99];
%             tau_const_list = [0.99];
%         end
        %% generate the data
        m =  mns_list(index,1);
        n =  mns_list(index,2);
        s =  mns_list(index,3);
        matfile = sprintf('./results-1/m%dn%ds%d_ntest%d_lam_%2.1e_%s.mat',m,n,s,ntest,lambda,datatype);
        load(matfile); 
        fprintf(fid, '(%d, %d, %d) &  %d & %4.2f & %6.4e &  %d & %4.2f & %6.4e &  %d & %4.2f & %6.4e\\\\ \n',...
            m,n,s,Perf(4,[4 6 3]),Perf(5,[4 6 3]),Perf(6,[4 6 3]));
    end
end