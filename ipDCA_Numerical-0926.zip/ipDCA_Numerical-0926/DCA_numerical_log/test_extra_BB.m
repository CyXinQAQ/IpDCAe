%这是一个测试外差和BB步长效果的理论
rng(20220129);
ntest = 30;
seedList = uint32(rand(ntest,1)*2^32)


T0 = tic;
T_eig = 0;
fid = fopen('history.txt','w+');
fid = 1;
datatype = 'randn';
datatype = 'dct';

datatypelist = {'randn', 'dct'};

% datatypelist = {'randn'};

for i_datatype = 2
    datatype =  datatypelist{i_datatype};
    switch datatype
        case 'randn'
            lambda_list = 1e-3;
            mns_list = [720 2560 80].* 1;
            % mns_list = [720 2560 80].*[1]';
        case 'dct'
            lambda_list = 1e-4;
            mns_list = [120 1800 48];
            %             mns_list = [100 1500 20];
    end
    for lambda = lambda_list
        for index = 1:size(mns_list,1)
            if lambda == 0.01
                tau_const_list = [0.75 0.8 0.85 0.90 0.95 0.99];
            else
                tau_const_list = [0.90 0.95 0.99];
                tau_const_list = [0.99];
            end
            n_solver = 4 + 4*length(tau_const_list); % + 1;
            Perf_ntest = zeros(2,4);
            Perf = zeros(n_solver,6);
            
            % Lines 1:3, nesterov, old, new, bb
            % the remaing lines: tau_const, old, new, bb
            % first column: extrap, 0 denotes nestrov,
            % second column: tau_method, 0:old, 1:new, 2: new2, 3: lbb, 4: sbb, 5: abb
            %% generate the data
            m =  mns_list(index,1);
            n =  mns_list(index,2);
            s =  mns_list(index,3);
            
            %matfile = sprintf('./results-extraBB/m%dn%ds%d_ntest%d_lam_%2.1e_%s.mat',m,n,s,ntest,lambda,datatype);
            %         s = 160*index;
            %         m = 100; n = 15*m; s = 0.2*m;
            % m = 100;
            % n = 10*m;
            % s = 0.2*m;
            % m = 100*index;
            % n = 5*m;
            % A = normrnd(0,1,m,n);
            fprintf(fid,'m: %4d, n: %4d, s: %4d,lambda: %4.2e\n',m,n,s,lambda);
            Perf_ntest=zeros(6,4);
            for itest = 1:ntest
                rng(seedList(itest,1));
                fprintf(fid,'-----------------------     itest: %2d/%2d       -----------------------\n',...
                    itest,ntest);
                switch datatype
                    case 'randn'
                        A = randn(m,n);
                        for i=1:n
                            A(:,i)=A(:,i)/norm(A(:,i));
                        end
                    case 'dct'
                        F = 10;
                        A = zeros(m,n);
                        w = rand(m,1);
                        for j = 1:n
                            A(:,j) = cos((2*pi*j*w)/F)/sqrt(m);
                        end
                end
                %                 tic
                %                 condA = cond(A'*A);
                %                 toc
                
                % 生成一个稀疏度为s的稀疏高斯分布的向量
                x_star=zeros(n,1);
                x_star(randperm(n,s))=randn(s,1);%n中s个位置生成高斯分布的向量
                %%
                % x_star=abs(x_star);
                eps=randn(m,1);
                b=A*x_star+0.01*eps;
                lambda_bound = 0.5*norm(A'*b,'inf');
                %L=max(eig(A'*A));
                t0_eig = tic;
                L = norm(A*A');
                t_eig = toc(t0_eig)
                T_eig = T_eig + t_eig;
                
                MaxIter = 2e8;
                %% do comparsion
                
                gtol = 1e-5;
                opts0.L = L;
                opts0.gtol = gtol;
                
                opts0.MaxIter = MaxIter;
                
                
                
                
                %%  
                Perf=zeros(6,4);
                BBstepList={'sbb','lbb','abb'};
                extraList={'nesterov','constant'};
                
                for extrai=1:2
                    for BBi=1:3
                opts = opts0;
                opts.tau_const=0;
                opts.extrap =extraList{extrai};
                opts.rt = 200;
                opts.tau_method = BBstepList{BBi};
                
                t0 = tic;
                
                out1= IPDCAe_new(A,b,lambda,n,opts);
                t_nestrov_sbb = toc(t0);
                x_nesterov_sbb=out1.x;
                f_nesterov_sbb=out1.f_value;
                iter_nesterov_sbb=out1.iter;
                nls_nesterov_sbb=out1.nls;
               
                fprintf(fid,'%10s-%5s: %6.4e, %4d, %4d, %4.3f\n',...
                    opts.extrap,opts.tau_method,f_nesterov_sbb, iter_nesterov_sbb,nls_nesterov_sbb,t_nestrov_sbb);
                Perf(3*(extrai-1)+BBi,:)=Perf(3*(extrai-1)+BBi,:)+[f_nesterov_sbb, iter_nesterov_sbb,nls_nesterov_sbb,t_nestrov_sbb];
                    end
                end
                Perf_ntest=Perf_ntest+Perf;               
            end
               Perf_ntest=Perf_ntest/ntest;
        
            
        end
    end
end

