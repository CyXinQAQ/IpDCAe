function y = shrinkage(x, kappa)
% tic
    y = max( 0, x - kappa ) - max( 0, -x - kappa );
%     t1 = toc
%     tic 
%     d = sign(x).*max(0,abs(x) - kappa);
%     t2 = toc
% norm(d - y)
end